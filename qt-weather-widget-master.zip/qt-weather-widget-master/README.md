Виджет погоды, разработанный с использованием фреймворка Qt (PySide6) и библиотеки requests.

Гайд по запуску:
1. Склонируйте проект командой ``git clone https://github.com/Haswell49/qt-weather-widget.git``
2. Установите все зависимости проекта:
```
python -m pip install -r requirements.txt
```
3. Запустите `src/__main__.py` из корневой директории проекта.

*Проект тестировался на версии Python 3.11.0
